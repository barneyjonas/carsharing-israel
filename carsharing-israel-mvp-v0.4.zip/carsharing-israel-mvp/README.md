# Carsharing Israel MVP v0.4

Static prototype for comparing carsharing and app-based short-term car access options in Israel.

## What is included

- Mobile-first homepage
- English/Hebrew language toggle
- RTL layout support for Hebrew
- Provider cards with company favicon/logo placeholders
- Comparison page with logo column inside provider cells
- Guide page
- Methodology page
- City-level coverage map using Leaflet + OpenStreetMap tiles
- Editable provider data in `js/providers.js`

## What is not included yet

- Login
- Booking
- Payment
- Live vehicle or station availability
- Exact station-level data
- Backend database
- TOMP-API integration

## Notes on logos

The MVP uses external favicon/logo URLs via `https://www.google.com/s2/favicons` as lightweight placeholders. For production, replace these with licensed official logo assets or provider-approved brand marks.

## How to open

Open `index.html` in a browser. The map and favicon/logo placeholders require an internet connection.

## Main files

- `index.html` — homepage
- `compare.html` — comparison table
- `guide.html` — user guide
- `methodology.html` — inclusion and verification logic
- `css/styles.css` — styling and RTL support
- `js/providers.js` — provider data, bilingual fields and logo URLs
- `js/i18n.js` — language toggle and translations
- `js/app.js` — filters and provider cards
- `js/map.js` — map rendering
- `js/compare.js` — comparison table rendering
